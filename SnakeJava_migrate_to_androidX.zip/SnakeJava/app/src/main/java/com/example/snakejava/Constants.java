package com.example.snakejava;

public class Constants {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
}
